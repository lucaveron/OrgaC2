#include "classify_chars.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void classify_chars_in_string(char* string, char** vowels_and_cons) {
}

void classify_chars(classifier_t* array, uint64_t size_of_array) {
}
